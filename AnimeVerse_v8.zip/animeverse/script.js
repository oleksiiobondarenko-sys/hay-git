/* AnimeVerse — логіка сайту (SPA на hash-маршрутах) */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const app = $('#app');
const state = { q: '', anime: 'Усі' };

/* ───────────── Портрет: фото або кольорова заглушка ───────────── */
function portraitBox(h, cls = '') {
  const src = h.photo || (h.custom ? '' : `img/${h.id}.jpg`);
  const img = src ? `<img src="${esc(src)}" alt="${esc(h.name)}" loading="lazy" onerror="this.remove()">` : '';
  return `<div class="portrait ${cls}" style="--a:${h.accent}"><span class="ph">${esc(h.symbol)}</span>${img}</div>`;
}

/* ───────────── Допоміжне ───────────── */
const animeList = () => ['Усі', ...new Set(allHeroes().map((h) => h.anime))];
const byId = (id) => allHeroes().find((h) => h.id === id);
const plural = (n) => (n % 10 === 1 && n % 100 !== 11 ? 'герой' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'герої' : 'героїв');
const norm = (s) => s.toLocaleLowerCase('uk');

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ───────────── Герої спільноти (додані користувачами) ───────────── */
const CUSTOM_KEY = 'animeverseCustom';
function hydrate(c) {
  const accent = /^#[0-9a-f]{6}$/i.test(c.accent || '') ? c.accent : '#a08cff';
  return { jp: '', traits: [], abilities: [], facts: [], bio: [], age: '', height: '', birthday: '', role: '', ...c, accent, symbol: [...c.name][0].toUpperCase(), custom: true };
}
let customCache = null;
function getCustom() {
  if (!customCache) {
    try { customCache = JSON.parse(localStorage.getItem(CUSTOM_KEY) || '[]').map(hydrate); } catch { customCache = []; }
  }
  return customCache;
}
function setCustom(list) {
  localStorage.setItem(CUSTOM_KEY, JSON.stringify(list)); // може кинути помилку, якщо переповнене сховище
  customCache = list.map(hydrate);
}
const allHeroes = () => [...HEROES, ...getCustom()];

/* ───────────── Історія переглядів ───────────── */
const histKey = () => `animeverseHistory:${currentUser() || 'guest'}`;
const getHistory = () => { try { return JSON.parse(localStorage.getItem(histKey()) || '[]'); } catch { return []; } };
const setHistory = (l) => localStorage.setItem(histKey(), JSON.stringify(l));
function recordVisit(id) {
  const list = getHistory().filter((x) => x.id !== id);
  list.unshift({ id, t: Date.now() });
  setHistory(list.slice(0, 60));
}
function when(t) {
  const d = new Date(t), now = new Date(), day = (x) => x.toDateString();
  const time = d.toLocaleTimeString('uk', { hour: '2-digit', minute: '2-digit' });
  if (day(d) === day(now)) return `Сьогодні, ${time}`;
  if (day(d) === day(new Date(now - 864e5))) return `Вчора, ${time}`;
  return `${d.toLocaleDateString('uk', { day: 'numeric', month: 'long' })}, ${time}`;
}


function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.hidden = false;
  t.classList.remove('show'); void t.offsetWidth; t.classList.add('show');
  clearTimeout(toast.t);
  toast.t = setTimeout(() => { t.hidden = true; t.classList.remove('show'); }, 2600);
}

/* ───────────── Акаунти (локальна демонстрація) ───────────── */
const getUsers = () => JSON.parse(localStorage.getItem('animeverseUsers') || '{}');
const currentUser = () => localStorage.getItem('animeverseUser');
const favKey = () => `animeverseFav:${currentUser()}`;
const getFavs = () => (currentUser() ? JSON.parse(localStorage.getItem(favKey()) || '[]') : []);
const setFavs = (a) => localStorage.setItem(favKey(), JSON.stringify(a));

async function hash(text) {
  try {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  } catch { return text; }
}

function renderAuthArea() {
  checkDaily(); renderNotifs();
  const box = $('#authArea');
  const user = currentUser();
  if (user) {
    box.innerHTML = `<div class="user-chip"><span class="avatar">${user[0].toUpperCase()}</span><span class="user-mail"></span><button class="btn btn-ghost btn-sm" id="logoutBtn" type="button">Вийти</button></div>`;
    $('.user-mail', box).textContent = user;
    $('#logoutBtn').addEventListener('click', () => {
      localStorage.removeItem('animeverseUser');
      renderAuthArea(); route(); toast('Ви вийшли з акаунта');
    });
  } else {
    box.innerHTML = `<div class="auth-buttons"><button class="btn btn-ghost" data-auth="login" type="button">Увійти</button><button class="btn btn-primary" data-auth="register" type="button">Реєстрація</button></div>`;
  }
}

const modal = $('#authModal');
let authMode = 'login';
function setAuthMode(mode) {
  authMode = mode;
  $$('.tab').forEach((t) => t.classList.toggle('active', t.dataset.mode === mode));
  $('#authTitle').textContent = mode === 'login' ? 'Увійти в акаунт' : 'Створити акаунт';
  $('#authSubmit').textContent = mode === 'login' ? 'Увійти' : 'Зареєструватися';
  $('#password').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  $('#formMessage').textContent = '';
}
function openAuth(mode = 'login') {
  setAuthMode(mode);
  modal.hidden = false;
  document.body.classList.add('no-scroll');
  setTimeout(() => $('#email').focus(), 50);
}
function closeAuth() { modal.hidden = true; document.body.classList.remove('no-scroll'); }

$('#authClose').addEventListener('click', closeAuth);
modal.addEventListener('click', (e) => { if (e.target === modal) closeAuth(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !modal.hidden) closeAuth(); });
$$('.tab').forEach((t) => t.addEventListener('click', () => setAuthMode(t.dataset.mode)));

$('#authForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = $('#formMessage');
  const email = $('#email').value.trim().toLowerCase();
  const pass = $('#password').value;
  if (!/^\S+@\S+\.\S+$/.test(email)) { msg.textContent = 'Введи коректну електронну пошту.'; return; }
  if (pass.length < 6) { msg.textContent = 'Пароль має містити щонайменше 6 символів.'; return; }
  const users = getUsers();
  const h = await hash(pass);
  if (authMode === 'register') {
    if (users[email]) { msg.textContent = 'Такий акаунт уже є в цьому браузері. Спробуй увійти.'; return; }
    users[email] = h;
    localStorage.setItem('animeverseUsers', JSON.stringify(users));
  } else if (users[email] !== h) {
    msg.textContent = 'Невірна пошта або пароль. Якщо ти новий користувач — зареєструйся.'; return;
  }
  localStorage.setItem('animeverseUser', email);
  $('#authForm').reset(); closeAuth(); renderAuthArea(); route();
  toast(authMode === 'register' ? 'Акаунт створено' : 'Ви увійшли');
  if (authMode === 'register') notify('Акаунт створено.', '#/heroes');
});

/* ───────────── Картки та сторінки ───────────── */
function card(h) {
  const fav = getFavs().includes(h.id);
  return `<a class="card character-card" href="#/hero/${h.id}" style="--a:${h.accent}" data-id="${h.id}">
    ${portraitBox(h)}
    ${fav ? '<span class="fav-badge">В обраному</span>' : ''}
    ${h.custom ? '<span class="community-badge">Від спільноти</span>' : ''}
    <div class="card-body">
      <span class="tag">${esc(h.anime)}</span>
      <h3>${esc(h.name)}</h3>
      <p>${esc(h.short)}</p>
      <div class="card-meta"><span>${esc(h.age)}</span><span>${esc(h.height)}</span></div>
      <span class="details-link">Детальніше <b>→</b></span>
    </div>
  </a>`;
}

function filterHeroes() {
  const q = norm(state.q.trim());
  return allHeroes().filter((h) => {
    if (state.anime !== 'Усі' && h.anime !== state.anime) return false;
    if (!q) return true;
    return norm([h.name, h.jp, h.anime, h.role, h.abilities.join(' ')].join(' ')).includes(q);
  });
}

function pageHome() {
  const featured = allHeroes().filter((h) => ['levi', 'gojo', 'naruto', 'luffy', 'tanjiro', 'ichigo', 'light', 'deku'].includes(h.id));
  const animes = animeList().slice(1);
  const hero3 = ['levi', 'gojo', 'naruto'].map(byId);
  const gallery = ['eren', 'mikasa', 'yuji', 'zoro', 'nezuko', 'sasuke', 'killua', 'edward'].map(byId);
  const recent = getHistory().map((x) => byId(x.id)).filter(Boolean).slice(0, 4);
  const recentHtml = recent.length ? `<section class="section">
    <div class="section-heading"><h2>Нещодавно переглянуті</h2><a class="link-more" href="#/history">Уся історія →</a></div>
    <div class="hero-grid">${recent.map(card).join('')}</div>
  </section>` : '';
  const n = allHeroes().length;
  return `
  <section class="hero-banner">
    <div class="hero-copy">
      <h1>Каталог<br><span>героїв аніме</span></h1>
      <p>${n} персонажів із ${animes.length} серіалів. У кожного є біографія, здібності та кілька фактів. Не знайшли свого героя — додайте його самі, разом із фото.</p>
      <div class="hero-cta">
        <a class="btn btn-primary btn-large" href="#/heroes">Відкрити каталог</a>
        <button class="btn btn-outline btn-large" id="randomHero" type="button">Випадковий герой</button>
      </div>
    </div>
    <div class="hero-faces" aria-hidden="true">
      ${hero3.map((h, i) => `<div class="face face-${i}">${portraitBox(h)}</div>`).join('')}
    </div>
  </section>

  ${recentHtml}
  <section class="section">
    <div class="section-heading"><h2>З чого почати</h2><a class="link-more" href="#/heroes">Усі герої →</a></div>
    <div class="hero-grid">${featured.map(card).join('')}</div>
  </section>

  <section class="section">
    <div class="section-heading"><h2>За серіалами</h2></div>
    <div class="anime-grid">
      ${animes.map((a) => {
        const list = allHeroes().filter((h) => h.anime === a);
        return `<button class="card anime-card" type="button" data-anime="${esc(a)}" style="--a:${list[0].accent}">
          <span class="anime-symbol">${esc(list[0].symbol)}</span>
          <strong>${esc(a)}</strong>
          <small>${list.length} ${plural(list.length)}</small>
        </button>`;
      }).join('')}
    </div>
  </section>

  <section class="section">
    <div class="section-heading"><h2>Галерея</h2><a class="link-more" href="#/heroes">Усі герої →</a></div>
    <div class="gallery">${gallery.map((h) => `<a class="gallery-item" href="#/hero/${h.id}" style="--a:${h.accent}" title="${esc(h.name)}">${portraitBox(h)}<span class="gallery-caption">${esc(h.name)}</span></a>`).join('')}</div>
  </section>

  <p class="add-strip">Не знайшли свого героя? <a href="#/add">Додайте його самі</a> — з описом і фото.</p>`;
}

function pageHeroes() {
  return `
  <div class="page-title title-row"><div><h1>Усі герої</h1></div><a class="btn btn-primary" href="#/add">Додати героя</a></div>
  <div class="filters" id="filters">${animeList().map((a) => `<button type="button" class="chip${a === state.anime ? ' active' : ''}" data-anime="${esc(a)}">${esc(a)}</button>`).join('')}</div>
  <p class="result-count" id="resultCount"></p>
  <div class="hero-grid" id="heroGrid"></div>
  <p class="empty-state" id="emptyState" hidden>Героїв не знайдено. Спробуй інший запит або фільтр.</p>`;
}

function updateGrid() {
  const list = filterHeroes();
  $('#heroGrid').innerHTML = list.map(card).join('');
  $('#resultCount').textContent = `${list.length} ${plural(list.length)}`;
  $('#emptyState').hidden = list.length !== 0;
  $$('#filters .chip').forEach((c) => c.classList.toggle('active', c.dataset.anime === state.anime));
  renderAnimeNav('heroes'); closeSidebar();
}

function pageFavorites() {
  if (!currentUser()) {
    return `<div class="page-title"><h1>Обране</h1></div>
    <div class="empty-box"><h2>Спочатку увійди в акаунт</h2><p>Обране доступне лише зареєстрованим користувачам.</p><button class="btn btn-primary" data-auth="login" type="button">Увійти</button></div>`;
  }
  const list = getFavs().map(byId).filter(Boolean);
  return `<div class="page-title"><h1>Обране</h1></div>` +
    (list.length
      ? `<div class="hero-grid">${list.map(card).join('')}</div>`
      : `<div class="empty-box"><h2>Тут поки порожньо</h2><p>Відкрий сторінку героя й натисни «Додати в обране».</p><a class="btn btn-primary" href="#/heroes">Переглянути героїв</a></div>`);
}

function pageHero(h) {
  const fav = getFavs().includes(h.id);
  const owner = h.custom && h.author && h.author === currentUser();
  const i = allHeroes().indexOf(h);
  const prev = allHeroes()[(i - 1 + allHeroes().length) % allHeroes().length];
  const next = allHeroes()[(i + 1) % allHeroes().length];
  const same = allHeroes().filter((x) => x.anime === h.anime && x.id !== h.id);
  const others = [...same, ...allHeroes().filter((x) => x.anime !== h.anime && x.id !== h.id)].slice(0, 4);
  return `
  <div class="hero-page" style="--a:${h.accent}">
    <a class="back-link" href="#/heroes">← Усі герої</a>

    <section class="profile">
      <div class="profile-photo">${portraitBox(h)}<span class="photo-label">${esc(h.anime)}</span></div>
      <div class="profile-main">
        <span class="tag">${esc(h.anime)}</span>
        <h1>${esc(h.name)}</h1>
        ${h.jp ? `<p class="jp">${esc(h.jp)}</p>` : ''}
        <p class="lead">${esc(h.short)}</p>
        ${h.custom ? `<p class="author">Героя додав(ла): <b>${esc(h.author || 'учасник')}</b></p>` : ''}
        <div class="traits">${h.traits.map((t) => `<span>${esc(t)}</span>`).join('')}</div>
        <dl class="stat-grid">
          <div><dt>Вік</dt><dd>${esc(h.age || '—')}</dd></div>
          <div><dt>Зріст</dt><dd>${esc(h.height || '—')}</dd></div>
          <div><dt>День народження</dt><dd>${esc(h.birthday || '—')}</dd></div>
          <div><dt>Роль</dt><dd>${esc(h.role || 'Герой спільноти')}</dd></div>
        </dl>
        <div class="profile-actions">
          <button class="btn btn-primary btn-large${fav ? ' is-fav' : ''}" id="favBtn" data-id="${h.id}" type="button">${fav ? 'В обраному ✓' : 'Додати в обране'}</button>
          <button class="btn btn-outline btn-large" id="randomHero" type="button">Випадковий герой</button>
          ${owner ? `<a class="btn btn-ghost btn-large" href="#/edit/${h.id}">Редагувати</a><button class="btn btn-ghost btn-large danger" data-del="${h.id}" type="button">Видалити</button>` : ''}
        </div>
      </div>
    </section>

    <div class="profile-body">
      <div class="profile-text">
        <article class="panel"><h2>Про героя</h2>${h.bio.map((p) => `<p>${esc(p)}</p>`).join('')}</article>
        ${h.abilities.length ? `<article class="panel"><h2>Здібності</h2><ul class="check-list">${h.abilities.map((a) => `<li>${esc(a)}</li>`).join('')}</ul></article>` : ''}
        ${h.facts.length ? `<article class="panel"><h2>Цікаві факти</h2><ul class="fact-list">${h.facts.map((f, n) => `<li><b>${String(n + 1).padStart(2, '0')}</b><span>${esc(f)}</span></li>`).join('')}</ul></article>` : ''}
      </div>
      <aside class="profile-side">
        <h2>Інші герої</h2>
        ${others.map((o) => `<a class="mini-card" href="#/hero/${o.id}" style="--a:${o.accent}">${portraitBox(o, 'mini')}<span><strong>${esc(o.name)}</strong><small>${esc(o.anime)}</small></span></a>`).join('')}
      </aside>
    </div>

    <nav class="pager" aria-label="Інші герої">
      <a href="#/hero/${prev.id}"><small>← Попередній</small><strong>${esc(prev.name)}</strong></a>
      <a href="#/hero/${next.id}" class="next"><small>Наступний →</small><strong>${esc(next.name)}</strong></a>
    </nav>
  </div>`;
}


function pageHistory() {
  const items = getHistory().map((x) => ({ h: byId(x.id), t: x.t })).filter((x) => x.h);
  const guest = currentUser() ? '' : '<p class="small-note guest-note">Ти не увійшов в акаунт — історія зберігається для гостя в цьому браузері.</p>';
  return `<div class="page-title title-row"><div><h1>Історія</h1></div>${items.length ? '<button class="btn btn-ghost" id="clearHist" type="button">Очистити історію</button>' : ''}</div>${guest}` +
    (items.length
      ? `<div class="history-list">${items.map(({ h, t }) => `<div class="history-item" style="--a:${h.accent}">
          <a class="history-link" href="#/hero/${h.id}">${portraitBox(h, 'mini')}<span><strong>${esc(h.name)}</strong><small>${esc(h.anime)} · ${when(t)}</small></span></a>
          <button class="icon-btn" data-hist-del="${h.id}" type="button" aria-label="Прибрати з історії">×</button></div>`).join('')}</div>`
      : '<div class="empty-box"><h2>Історія порожня</h2><p>Тут з’являтимуться герої, чиї сторінки ти відкривав.</p><a class="btn btn-primary" href="#/heroes">Переглянути героїв</a></div>');
}

let formPhoto = null;
function photoPreviewHtml() {
  return formPhoto ? `<img src="${esc(formPhoto)}" alt="Попередній перегляд фото">` : '<div class="photo-empty"><small>Фото не обрано</small></div>';
}
function updatePhotoPreview() { const el = $('#photoPreview'); if (el) el.innerHTML = photoPreviewHtml(); }

function pageForm(h) {
  if (!currentUser()) {
    return `<div class="page-title"><h1>Додати героя</h1></div>
    <div class="empty-box"><h2>Спочатку увійди в акаунт</h2><p>Додавати героїв можуть лише зареєстровані користувачі.</p><button class="btn btn-primary" data-auth="login" type="button">Увійти</button></div>`;
  }
  if (h === undefined) {
    return '<div class="empty-box"><h2>Не можна редагувати</h2><p>Редагувати героя може лише той, хто його додав.</p><a class="btn btn-primary" href="#/heroes">До каталогу</a></div>';
  }
  formPhoto = h ? h.photo || null : null;
  const v = (k) => esc(h ? h[k] || '' : '');
  const lines = (k) => esc(h ? (h[k] || []).join('\n') : '');
  const animeOptions = [...new Set(allHeroes().map((x) => x.anime))].map((a) => `<option value="${esc(a)}">`).join('');
  return `<div class="page-title"><h1>${h ? 'Редагувати героя' : 'Додати героя'}</h1></div>
  <form class="hero-form" id="heroForm" data-edit="${h ? h.id : ''}" novalidate>
    <div class="form-layout">
      <div class="photo-upload panel">
        <div class="photo-preview" id="photoPreview">${photoPreviewHtml()}</div>
        <label class="btn btn-outline full-width">Обрати фото<input type="file" id="photoInput" accept="image/*" hidden></label>
        <button class="btn btn-ghost btn-sm full-width" id="photoRemove" type="button">Прибрати фото</button>
        <p class="small-note">JPG, PNG або WebP. Фото зменшується та зберігається лише в цьому браузері. Без фото буде показано кольорову заглушку.</p>
      </div>
      <div class="form-fields panel">
        <label class="form-row"><span>Ім’я героя *</span><input class="input" type="text" name="name" maxlength="60" value="${v('name')}" placeholder="Наприклад, Рем" required></label>
        <label class="form-row"><span>Аніме / серія *</span><input class="input" type="text" name="anime" list="animeOptions" maxlength="60" value="${v('anime')}" placeholder="Обери зі списку або введи своє" required><datalist id="animeOptions">${animeOptions}</datalist></label>
        <label class="form-row"><span>Короткий опис * <small>(1–2 речення для картки)</small></span><textarea class="input" name="short" rows="2" maxlength="180" required>${v('short')}</textarea></label>
        <label class="form-row"><span>Повний опис / біографія * <small>(кожен абзац з нового рядка)</small></span><textarea class="input" name="bio" rows="7" required>${lines('bio')}</textarea></label>
        <div class="row-2">
          <label class="form-row"><span>Вік</span><input class="input" type="text" name="age" maxlength="30" value="${v('age')}" placeholder="17"></label>
          <label class="form-row"><span>Зріст</span><input class="input" type="text" name="height" maxlength="30" value="${v('height')}" placeholder="160 см"></label>
        </div>
        <div class="row-2">
          <label class="form-row"><span>День народження</span><input class="input" type="text" name="birthday" maxlength="30" value="${v('birthday')}" placeholder="2 вересня"></label>
          <label class="form-row"><span>Роль / посада</span><input class="input" type="text" name="role" maxlength="80" value="${v('role')}" placeholder="Студент, воїн…"></label>
        </div>
        <label class="form-row"><span>Риси характеру <small>(через кому)</small></span><input class="input" type="text" name="traits" maxlength="120" value="${esc(h ? (h.traits || []).join(', ') : '')}" placeholder="Добрий, сміливий, впертий"></label>
        <label class="form-row"><span>Здібності <small>(кожна з нового рядка)</small></span><textarea class="input" name="abilities" rows="3">${lines('abilities')}</textarea></label>
        <label class="form-row"><span>Цікаві факти <small>(кожен з нового рядка)</small></span><textarea class="input" name="facts" rows="3">${lines('facts')}</textarea></label>
        <label class="form-row color-row"><span>Колір героя</span><input type="color" name="accent" value="${h ? h.accent : '#a08cff'}"></label>
      </div>
    </div>
    <p class="form-message" id="heroFormMsg" role="status"></p>
    <div class="form-actions"><button class="btn btn-primary btn-large" type="submit">${h ? 'Зберегти зміни' : 'Опублікувати героя'}</button><a class="btn btn-ghost btn-large" href="${h ? '#/hero/' + h.id : '#/heroes'}">Скасувати</a></div>
  </form>`;
}

function readPhoto(file) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) return reject(new Error('Обери файл зображення (JPG, PNG, WebP).'));
    if (file.size > 12 * 1024 * 1024) return reject(new Error('Файл завеликий (максимум 12 МБ).'));
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('Не вдалося прочитати файл.'));
    fr.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Не вдалося відкрити зображення.'));
      img.onload = () => {
        const k = Math.min(1, 720 / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#0a1424'; ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', 0.85));
      };
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}

/* ───────────── Маршрутизація ───────────── */
function route() {
  const [page, arg] = location.hash.replace(/^#\/?/, '').split('/');
  let html, nav = 'home', title = 'AnimeVerse — фан-вікі';
  if (page === 'heroes') { html = pageHeroes(); nav = 'heroes'; title = 'Герої — AnimeVerse'; }
  else if (page === 'favorites') { html = pageFavorites(); nav = 'favorites'; title = 'Обране — AnimeVerse'; }
  else if (page === 'history') { html = pageHistory(); nav = 'history'; title = 'Історія — AnimeVerse'; }
  else if (page === 'add') { html = pageForm(null); nav = 'add'; title = 'Додати героя — AnimeVerse'; }
  else if (page === 'edit') { const e = byId(arg); html = pageForm(e && e.custom && e.author === currentUser() ? e : undefined); nav = 'add'; title = 'Редагувати героя — AnimeVerse'; }
  else if (page === 'hero' && byId(arg)) { const h = byId(arg); recordVisit(h.id); html = pageHero(h); nav = 'heroes'; title = `${esc(h.name)} — AnimeVerse`; }
  else if (page === 'hero') { html = `<div class="empty-box"><h2>Героя не знайдено</h2><a class="btn btn-primary" href="#/heroes">До списку героїв</a></div>`; nav = 'heroes'; }
  else { html = pageHome(); }
  app.innerHTML = `<div class="page">${html}</div>`;
  document.title = title;
  $$('.main-nav a').forEach((a) => a.classList.toggle('active', a.dataset.nav === nav));
  closeSidebar(); renderAnimeNav(page); updateNavBadges(); renderRail();
  if (page === 'heroes') updateGrid();
  window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
}
window.addEventListener('hashchange', route);

/* ───────────── Бічна панель, повідомлення, правий блок ───────────── */
function closeSidebar() {
  $('#sidebar').classList.remove('open');
  $('#sidebarBackdrop').hidden = true;
  $('#menuToggle').setAttribute('aria-expanded', 'false');
}
$('#menuToggle').addEventListener('click', () => {
  const open = $('#sidebar').classList.toggle('open');
  $('#sidebarBackdrop').hidden = !open;
  $('#menuToggle').setAttribute('aria-expanded', String(open));
});
$('#sidebarBackdrop').addEventListener('click', closeSidebar);

function renderAnimeNav(page) {
  const all = allHeroes();
  $('#animeNav').innerHTML = animeList().slice(1).map((a) => {
    const list = all.filter((h) => h.anime === a);
    const active = page === 'heroes' && state.anime === a;
    return `<button class="nav-anime${active ? ' active' : ''}" data-anime="${esc(a)}" style="--a:${list[0].accent}" type="button"><i></i><span class="nav-anime-name">${esc(a)}</span><small>${list.length}</small></button>`;
  }).join('');
}

function updateNavBadges() {
  const n = getFavs().filter(byId).length, el = $('#favCount');
  el.hidden = !n; el.textContent = n;
}

const dailyHero = () => { const all = allHeroes(); return all[Math.floor(Date.now() / 864e5) % all.length]; };

function renderRail() {
  const all = allHeroes(), dod = dailyHero();
  const recent = getHistory().map((x) => byId(x.id)).filter(Boolean).slice(0, 3);
  const top = animeList().slice(1).map((a) => [a, all.filter((h) => h.anime === a).length]).sort((x, y) => y[1] - x[1]).slice(0, 5);
  $('#rail').innerHTML = `
    <a class="widget dod" href="#/hero/${dod.id}" style="--a:${dod.accent}"><h3>Герой дня</h3><div class="dod-photo">${portraitBox(dod)}</div><strong>${esc(dod.name)}</strong><small>${esc(dod.anime)}</small><p>${esc(dod.short)}</p></a>
    <div class="widget"><h3>Твоя активність</h3><div class="rail-stats"><div><b>${all.length}</b><span>героїв</span></div><div><b>${getFavs().filter(byId).length}</b><span>в обраному</span></div><div><b>${getHistory().length}</b><span>переглядів</span></div></div></div>
    <div class="widget"><h3>Топ світів</h3>${top.map(([a, n]) => `<button class="nav-anime" data-anime="${esc(a)}" type="button"><span class="nav-anime-name">${esc(a)}</span><small>${n}</small></button>`).join('')}</div>
    ${recent.length ? `<div class="widget"><h3>Нещодавно</h3>${recent.map((o) => `<a class="mini-card" href="#/hero/${o.id}" style="--a:${o.accent}">${portraitBox(o, 'mini')}<span><strong>${esc(o.name)}</strong><small>${esc(o.anime)}</small></span></a>`).join('')}</div>` : ''}`;
}

/* Повідомлення (окремо для кожного акаунта / гостя) */
const notifKey = () => `animeverseNotifs:${currentUser() || 'guest'}`;
function getNotifs() {
  const raw = localStorage.getItem(notifKey());
  if (raw === null) {
    const seed = [
      { text: 'Каталог героїв — у розділі «Герої».', link: '#/heroes' },
      { text: 'Власного героя можна додати в розділі «Додати героя».', link: '#/add' }
    ].map((n, i) => ({ ...n, id: `s${i}`, t: Date.now() - i * 60000, read: false }));
    localStorage.setItem(notifKey(), JSON.stringify(seed));
    return seed;
  }
  try { return JSON.parse(raw); } catch { return []; }
}
const setNotifs = (l) => localStorage.setItem(notifKey(), JSON.stringify(l.slice(0, 30)));
function notify(text, link = '') {
  setNotifs([{ id: String(Date.now()), text, link, t: Date.now(), read: false }, ...getNotifs()]);
  renderNotifs();
}
function renderNotifs() {
  const list = getNotifs(), unread = list.filter((n) => !n.read).length, badge = $('#bellBadge');
  badge.hidden = !unread; badge.textContent = unread > 9 ? '9+' : unread;
  $('#notifList').innerHTML = list.length
    ? list.map((n) => `<button class="notif-item${n.read ? '' : ' unread'}" data-notif="${esc(n.id)}" data-link="${esc(n.link)}" type="button"><span class="notif-dot"></span><span>${esc(n.text)}<small>${when(n.t)}</small></span></button>`).join('')
    : '<p class="notif-empty">Повідомлень немає</p>';
}
function checkDaily() {
  const k = `animeverseDay:${currentUser() || 'guest'}`, today = new Date().toDateString();
  if (localStorage.getItem(k) === today) return;
  localStorage.setItem(k, today);
  const h = dailyHero();
  notify(`Герой дня: ${h.name} (${h.anime})`, `#/hero/${h.id}`);
}

document.addEventListener('click', (e) => {
  if (e.target.closest('#bellBtn')) { $('#notifPanel').hidden = !$('#notifPanel').hidden; return; }
  if (e.target.closest('#readAll')) { setNotifs(getNotifs().map((n) => ({ ...n, read: true }))); renderNotifs(); return; }
  if (e.target.closest('#clearNotifs')) { setNotifs([]); renderNotifs(); return; }
  const it = e.target.closest('[data-notif]');
  if (it) {
    setNotifs(getNotifs().map((n) => (n.id === it.dataset.notif ? { ...n, read: true } : n)));
    renderNotifs(); $('#notifPanel').hidden = true;
    if (it.dataset.link) location.hash = it.dataset.link;
    return;
  }
  if (!e.target.closest('.notif')) $('#notifPanel').hidden = true;
});
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { $('#notifPanel').hidden = true; closeSidebar(); } });

/* ───────────── Події ───────────── */
document.addEventListener('click', (e) => {
  const auth = e.target.closest('[data-auth]');
  if (auth) { openAuth(auth.dataset.auth); return; }

  const animeBtn = e.target.closest('[data-anime]');
  if (animeBtn) {
    state.anime = animeBtn.dataset.anime;
    if (location.hash.startsWith('#/heroes')) updateGrid();
    else location.hash = '#/heroes';
    return;
  }

  if (e.target.closest('#randomHero')) {
    const cur = (location.hash.match(/#\/hero\/(\w+)/) || [])[1];
    let h; do { h = allHeroes()[Math.floor(Math.random() * allHeroes().length)]; } while (h.id === cur);
    location.hash = `#/hero/${h.id}`;
    return;
  }

  const fav = e.target.closest('#favBtn');
  if (fav) {
    if (!currentUser()) { openAuth('login'); toast('Увійди, щоб користуватися обраним'); return; }
    const id = fav.dataset.id;
    let list = getFavs();
    const had = list.includes(id);
    list = had ? list.filter((x) => x !== id) : [...list, id];
    setFavs(list);
    fav.classList.toggle('is-fav', !had);
    fav.textContent = had ? 'Додати в обране' : 'В обраному ✓';
    toast(had ? 'Видалено з обраного' : 'Додано до обраного');
    if (!had) notify(`«${byId(id).name}» додано до обраного`, '#/favorites');
    updateNavBadges(); renderRail();
  }
});

$('#searchInput').addEventListener('input', (e) => {
  state.q = e.target.value;
  if (location.hash.startsWith('#/heroes')) updateGrid();
  else location.hash = '#/heroes';
});


/* Додавання / редагування героя, видалення, історія */
document.addEventListener('change', async (e) => {
  if (e.target.id !== 'photoInput') return;
  const file = e.target.files[0];
  if (!file) return;
  const msg = $('#heroFormMsg');
  try { formPhoto = await readPhoto(file); msg.textContent = ''; } catch (err) { msg.textContent = err.message; }
  updatePhotoPreview();
  e.target.value = '';
});

document.addEventListener('submit', (e) => {
  if (e.target.id !== 'heroForm') return;
  e.preventDefault();
  const user = currentUser(), msg = $('#heroFormMsg');
  if (!user) { openAuth('login'); return; }
  const fd = new FormData(e.target);
  const val = (k) => (fd.get(k) || '').toString().trim();
  const lines = (k) => val(k).split(/\n+/).map((x) => x.trim()).filter(Boolean);
  const bio = lines('bio');
  if (val('name').length < 2) { msg.textContent = 'Вкажи ім’я героя (щонайменше 2 символи).'; return; }
  if (!val('anime')) { msg.textContent = 'Вкажи, з якого він аніме.'; return; }
  if (val('short').length < 10) { msg.textContent = 'Додай короткий опис (щонайменше 10 символів).'; return; }
  if (bio.join(' ').length < 30) { msg.textContent = 'Повний опис занадто короткий — напиши хоча б кілька речень.'; return; }
  const editId = e.target.dataset.edit;
  const list = getCustom();
  const old = editId ? list.find((x) => x.id === editId) : null;
  if (editId && (!old || old.author !== user)) { msg.textContent = 'Ти не можеш редагувати цього героя.'; return; }
  const hero = {
    id: old ? old.id : `c_${Date.now().toString(36)}${Math.floor(Math.random() * 1e3)}`,
    name: val('name'), anime: val('anime'), short: val('short'), bio,
    abilities: lines('abilities'), facts: lines('facts'),
    traits: val('traits').split(',').map((x) => x.trim()).filter(Boolean).slice(0, 6),
    age: val('age'), height: val('height'), birthday: val('birthday'), role: val('role'),
    accent: val('accent') || '#a08cff', photo: formPhoto || null,
    author: old ? old.author : user, created: old ? old.created : Date.now()
  };
  try {
    setCustom(old ? list.map((x) => (x.id === old.id ? hero : x)) : [...list, hero]);
  } catch {
    msg.textContent = 'Не вдалося зберегти: у браузері закінчилося місце. Спробуй менше фото або видали зайвих героїв.';
    return;
  }
  toast(old ? 'Зміни збережено' : 'Героя додано');
  if (!old) notify(`Ви додали героя «${hero.name}»`, `#/hero/${hero.id}`);
  location.hash = `#/hero/${hero.id}`;
});

document.addEventListener('click', (e) => {
  if (e.target.closest('#photoRemove')) { formPhoto = null; updatePhotoPreview(); return; }

  const del = e.target.closest('[data-del]');
  if (del) {
    const h = byId(del.dataset.del);
    if (h && h.custom && h.author === currentUser() && confirm(`Видалити героя «${h.name}»? Цю дію не можна скасувати.`)) {
      setCustom(getCustom().filter((x) => x.id !== h.id));
      toast('Героя видалено');
      location.hash = '#/heroes';
    }
    return;
  }

  const hd = e.target.closest('[data-hist-del]');
  if (hd) { setHistory(getHistory().filter((x) => x.id !== hd.dataset.histDel)); route(); return; }

  if (e.target.closest('#clearHist')) {
    if (confirm('Очистити всю історію переглядів?')) { setHistory([]); route(); toast('Історію очищено'); }
  }
});

/* Плаваюча кнопка «нагору» */
const btnTop = $('#btnTop');
window.addEventListener('scroll', () => btnTop.classList.toggle('visible', window.scrollY > 400), { passive: true });
btnTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

renderAuthArea();
route();
